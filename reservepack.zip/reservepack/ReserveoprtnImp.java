package reservepack;

import java.util.*;

public class ReserveoprtnImp implements Reserveop{
	HashMap<Integer,String> reservations=new HashMap<>();
    private static int totalseats=5;
    Scanner in=new Scanner(System.in);
	@Override
	public void bookTicket() {
		if(reservations.size()>=totalseats)
		{
			System.out.println("sorry... All seats are reserved");
		}
		else
		{
			System.out.println("Enter your name");
			String PassengerName=in.next();
			System.out.println("Enter the seat number from 1-"+ totalseats);
			int Seatnum=in.nextInt();
			if(reservations.containsKey(Seatnum) || Seatnum>totalseats)
			{
				 System.out.println("please choose available or valid seat number")	;
			}
			else {
				System.out.println("reservation successfull"+" seatnum "+Seatnum+" name "+PassengerName);
				reservations.put(Seatnum, "occupied");
				viewTickets();
			}
			 
		}
		
	}
		
	

	@Override
	public void CancelTicket() {
		System.out.println("Enter  your seat number");
		int Seatnum=in.nextInt();
		if(reservations.containsKey(Seatnum))
		{
			System.out.println(Seatnum+"Cancelled");
			reservations.remove(Seatnum);
		}
		else
			
		{
			System.out.println("this seatnumber is not yet reserved");
		}
		
	}

	@Override
	public void viewTickets() {
		if(reservations.isEmpty()) {
			System.out.println("all seat are available");
		}
		else
		{
			for(Map.Entry<Integer, String>m:reservations.entrySet())
			{
				System.out.println(m.getKey()+" "+m.getValue());
			}
		}
		
		
	}

}
