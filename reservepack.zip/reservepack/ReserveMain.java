package reservepack;

import java.util.Scanner;

public class ReserveMain {

	public static void main(String[] args) {
		//creating constructor or instance for ReserveoprtnImp 
		ReserveoprtnImp re=new ReserveoprtnImp();
		//print the welcome message to the console
		System.out.println("welcome to airline reservation");
		//this is infinite loop which will keep running until the user decides to exit
		while(true) {
			//this line print the menu option 
			System.out.println("1.book ticket\n 2.cancle ticket\n 3.view chart\n 4.exit");
			//provide the user to enter the choice
			System.out.println("Enter your choice");
			Scanner in=new Scanner(System.in);
			int ch=in.nextInt();
			if(ch==1)
			{
				re.bookTicket();
			}
			else if(ch==2)
			{
				re.CancelTicket();
			}
			else if(ch==3)
			{
				re.viewTickets();
			}
			else if(ch==4)
			{
				System.out.println("thank you using airline reservation system");
				System.exit(0);
			}
			else
			{
				System.out.println("your choice is invalid...try again");
			}
		}


	}

}
