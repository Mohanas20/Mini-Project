package reservepack;

public interface Reserveop {
	 public void bookTicket();
     public void CancelTicket();
     public void viewTickets();
}
